<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2022 <a href="#"></a> <a href=""></a> Rusukh. All Rights Reserved  .</span>
		</div>
	</div>
<!-- Footer closed -->
